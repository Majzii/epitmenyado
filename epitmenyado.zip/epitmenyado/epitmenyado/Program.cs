﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace epitmenyado
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Építményadó feljegyző program");
            
            StreamReader olvas = new StreamReader("utca.txt");
            olvas.ReadToEnd();
            string[] tomb = new string[10000];
            Console.Write("Kérem adja meg az adószámát (5db szám): ");   
            int adoszam = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ez az adószáma?" +adoszam);
            



            Console.ReadKey();
        }
    }
}
